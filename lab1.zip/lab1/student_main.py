def task1(str):
    return len(str)


def task2(a , operator, b):
    if operator == "+":
        return a + b
    elif operator == "-":
        return a - b
    elif operator == "/":
        return a / b
    elif operator == "//":
        return a // b
    elif operator == "**":
        return a ** b
    elif operator == "*":
        return a * b

def task3(list):
    return max(list)

